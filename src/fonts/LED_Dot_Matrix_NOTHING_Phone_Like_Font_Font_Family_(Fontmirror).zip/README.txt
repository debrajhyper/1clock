To learn more about the font family and its license, visit https://www.fontmirror.com/led-dot-matrix

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://crmrkt.com/6ovbaA.